from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from flask import current_app

from app.common.pagination import PER_PAGE_OPTIONS, build_pagination_window
from app.common.presentation import present_key_label, present_user_datetime
from app.extensions.db import db
from app.integrations.resolver_bootstrap import get_resolver_registry
from app.models.audit import AuditEvent
from app.models.cluster import Cluster
from app.models.intelligence import (
    IntelligenceDecision,
    IntelligenceDecisionCandidate,
    IntelligenceExecutionJournal,
)
from app.models.knowledge import (
    KnowledgeRunbook,
    KnowledgeRunbookAlertBinding,
    KnowledgeRunbookRevision,
)
from app.models.resolver import (
    ResolverDeploymentPolicy,
    ResolverOperationalControl,
    ResolverProductionReadinessRecord,
)
from app.resolver.production_readiness import REQUIRED_CHECKS, STAGE_ORDER, assess_readiness

WORKSPACE_KEYS = ('overview', 'runbooks', 'decisions', 'operations', 'readiness')


@dataclass(frozen=True, slots=True)
class DomainDefinition:
    number: int
    title: str
    layer: str
    operator_surface: str
    evidence: str


DOMAIN_DEFINITIONS: tuple[DomainDefinition, ...] = (
    DomainDefinition(
        1, 'Authentication & RBAC Hardening', 'Access', 'Existing Settings UI', 'Server-side permission enforcement'
    ),
    DomainDefinition(
        2,
        'Job & Integration Runtime Safety',
        'Runtime',
        'Existing Jobs and Integrations UI',
        'Admission locks and terminal-state integrity',
    ),
    DomainDefinition(
        3,
        'Kubernetes Canonical Inventory',
        'Inventory',
        'Existing Kubernetes UI',
        'Atomic committed inventory generation',
    ),
    DomainDefinition(
        4, 'Prometheus Runtime Stabilization', 'Metrics', 'Existing Prometheus UI', 'Capability-aware source selection'
    ),
    DomainDefinition(
        5,
        'Alertmanager Runtime Stabilization',
        'Alerts',
        'Existing Alertmanager UI',
        'Lifecycle-aware alert source selection',
    ),
    DomainDefinition(
        6,
        'Shared Integration Foundation',
        'Integration',
        'Existing Integrations UI',
        'Canonical provider lifecycle contract',
    ),
    DomainDefinition(
        7,
        'Intelligence Evidence Consistency',
        'Intelligence',
        'Recommendations & Catalog',
        'Committed-generation recommendation evidence',
    ),
    DomainDefinition(
        8, 'Decision Execution Boundary', 'Decision', 'Decision Review', 'Immutable time-bounded decision snapshot'
    ),
    DomainDefinition(
        9, 'Decision Approval Workflow', 'Decision', 'Decision Review', 'Persisted approval and rejection evidence'
    ),
    DomainDefinition(
        10, 'Safe Resolver Engine', 'Resolver', 'Resolver Operations', 'Provider-neutral allowlisted action contract'
    ),
    DomainDefinition(
        11,
        'Distributed Execution Orchestration',
        'Resolver',
        'Resolver Operations',
        'Lease, retry, dead-letter, and idempotency state',
    ),
    DomainDefinition(
        12,
        'Knowledge Runbook Foundation',
        'Knowledge',
        'Runbooks & Bindings',
        'Stable identity and immutable revisions',
    ),
    DomainDefinition(
        13,
        'Runbook Authoring Validation',
        'Knowledge',
        'Runbooks & Bindings',
        'Publication validation against resolver contracts',
    ),
    DomainDefinition(
        14, 'Alert-to-Runbook Matching', 'Knowledge', 'Runbooks & Bindings', 'Deterministic alert selector binding'
    ),
    DomainDefinition(
        15, 'Candidate Review & Promotion', 'Decision', 'Decision Review', 'Non-executable review candidate lifecycle'
    ),
    DomainDefinition(
        16, 'Kubernetes Resolver Adapter', 'Resolver', 'Resolver Operations', 'Allowlisted deployment restart adapter'
    ),
    DomainDefinition(
        17,
        'Resolver Registry & Deployment Policy',
        'Resolver',
        'Resolver Operations',
        'Registry fingerprint and scoped policy',
    ),
    DomainDefinition(
        18,
        'End-to-End Remediation Workflow',
        'Automation',
        'Decision Review',
        'Explicit alert-to-review-to-resolver transitions',
    ),
    DomainDefinition(
        19,
        'Operational Controls & Observability',
        'Operations',
        'Resolver Operations',
        'Kill switch, limits, circuit breaker, dead letter',
    ),
    DomainDefinition(
        20,
        'Production Readiness & Rollout',
        'Governance',
        'Production Readiness',
        'Evidence checklist and staged rollout',
    ),
)


def build_automation_control_context(query_args: Mapping[str, Any]) -> dict[str, Any]:
    workspace = str(query_args.get('workspace') or 'overview').strip().lower()
    if workspace not in WORKSPACE_KEYS:
        workspace = 'overview'
    page = query_args.get('page', 1)
    per_page = query_args.get('per_page', 5)

    clusters = Cluster.query.order_by(Cluster.name.asc(), Cluster.id.asc()).all()
    cluster_names = {str(cluster.id): cluster.name for cluster in clusters}
    registry_rows, registry_fingerprint = _registry_rows()

    counts = {
        'runbooks': KnowledgeRunbook.query.count(),
        'published_revisions': KnowledgeRunbookRevision.query.filter_by(publication_status='published').count(),
        'pending_candidates': IntelligenceDecisionCandidate.query.filter_by(review_status='pending').count(),
        'pending_decisions': IntelligenceDecision.query.filter(
            IntelligenceDecision.workflow_status.in_(('ready', 'pending_approval', 'approved'))
        ).count(),
        'dead_letters': IntelligenceExecutionJournal.query.filter_by(orchestration_status='dead_letter').count(),
        'readiness_records': ResolverProductionReadinessRecord.query.count(),
    }

    payload: dict[str, Any] = {
        'workspace': workspace,
        'workspaces': _workspace_rows(workspace),
        'counts': counts,
        'clusters': clusters,
        'cluster_names': cluster_names,
        'registry_rows': registry_rows,
        'registry_fingerprint': registry_fingerprint,
        'required_checks': REQUIRED_CHECKS,
        'stage_order': STAGE_ORDER,
        'per_page_options': PER_PAGE_OPTIONS,
        'global_control': ResolverOperationalControl.query.filter_by(cluster_id=None).one_or_none(),
        'domain_rows': [],
        'runbook_rows': [],
        'revision_rows': [],
        'binding_rows': [],
        'candidate_rows': [],
        'decision_rows': [],
        'journal_rows': [],
        'policy_rows': [],
        'control_rows': [],
        'readiness_rows': [],
        'pagination': None,
        'resource_label': 'items',
    }

    if workspace == 'overview':
        rows = [_domain_row(item) for item in DOMAIN_DEFINITIONS]
        payload['domain_rows'], payload['pagination'] = _paginate_sequence(rows, page=page, per_page=per_page)
        payload['resource_label'] = 'domains'
    elif workspace == 'runbooks':
        query = KnowledgeRunbook.query.order_by(KnowledgeRunbook.updated_at.desc(), KnowledgeRunbook.id.desc())
        records, pagination = _paginate_query(query, page=page, per_page=per_page)
        payload['runbook_rows'] = [_runbook_row(record) for record in records]
        payload['revision_rows'] = [
            _revision_row(record)
            for record in KnowledgeRunbookRevision.query.order_by(
                KnowledgeRunbookRevision.created_at.desc(), KnowledgeRunbookRevision.id.desc()
            )
            .limit(10)
            .all()
        ]
        payload['binding_rows'] = [
            _binding_row(record)
            for record in KnowledgeRunbookAlertBinding.query.order_by(
                KnowledgeRunbookAlertBinding.priority.asc(), KnowledgeRunbookAlertBinding.id.desc()
            )
            .limit(10)
            .all()
        ]
        payload['published_revisions'] = (
            KnowledgeRunbookRevision.query.filter_by(publication_status='published')
            .order_by(KnowledgeRunbookRevision.published_at.desc(), KnowledgeRunbookRevision.id.desc())
            .all()
        )
        payload['all_runbooks'] = KnowledgeRunbook.query.order_by(KnowledgeRunbook.title.asc()).all()
        payload['pagination'] = pagination
        payload['resource_label'] = 'runbooks'
    elif workspace == 'decisions':
        query = IntelligenceDecisionCandidate.query.order_by(
            IntelligenceDecisionCandidate.created_at.desc(), IntelligenceDecisionCandidate.id.desc()
        )
        records, pagination = _paginate_query(query, page=page, per_page=per_page)
        payload['candidate_rows'] = [_candidate_row(record, cluster_names) for record in records]
        payload['decision_rows'] = [
            _decision_row(record, cluster_names)
            for record in IntelligenceDecision.query.order_by(
                IntelligenceDecision.created_at.desc(), IntelligenceDecision.id.desc()
            )
            .limit(10)
            .all()
        ]
        payload['journal_rows'] = [
            _journal_row(record, cluster_names)
            for record in IntelligenceExecutionJournal.query.order_by(
                IntelligenceExecutionJournal.created_at.desc(), IntelligenceExecutionJournal.id.desc()
            )
            .limit(10)
            .all()
        ]
        payload['pagination'] = pagination
        payload['resource_label'] = 'candidates'
    elif workspace == 'operations':
        query = ResolverDeploymentPolicy.query.order_by(
            ResolverDeploymentPolicy.updated_at.desc(), ResolverDeploymentPolicy.id.desc()
        )
        records, pagination = _paginate_query(query, page=page, per_page=per_page)
        payload['policy_rows'] = [_policy_row(record, cluster_names) for record in records]
        payload['control_rows'] = [
            _control_row(record, cluster_names)
            for record in ResolverOperationalControl.query.order_by(
                ResolverOperationalControl.cluster_id.asc().nullsfirst(), ResolverOperationalControl.id.asc()
            ).all()
        ]
        payload['journal_rows'] = [
            _journal_row(record, cluster_names)
            for record in IntelligenceExecutionJournal.query.filter_by(orchestration_status='dead_letter')
            .order_by(IntelligenceExecutionJournal.updated_at.desc(), IntelligenceExecutionJournal.id.desc())
            .limit(10)
            .all()
        ]
        payload['metrics'] = _resolver_metrics()
        payload['pagination'] = pagination
        payload['resource_label'] = 'deployment policies'
    else:
        query = ResolverProductionReadinessRecord.query.order_by(
            ResolverProductionReadinessRecord.updated_at.desc(), ResolverProductionReadinessRecord.id.desc()
        )
        records, pagination = _paginate_query(query, page=page, per_page=per_page)
        payload['readiness_rows'] = [_readiness_row(record, cluster_names) for record in records]
        payload['pagination'] = pagination
        payload['resource_label'] = 'readiness records'

    return payload


def upsert_deployment_policy(
    *,
    cluster_id: str,
    action_key: str,
    lifecycle_status: str,
    allowed_namespaces: Sequence[str],
    required_registry_fingerprint: str | None,
    actor_user_id: int | None,
) -> ResolverDeploymentPolicy:
    if lifecycle_status not in {'active', 'disabled'}:
        raise ValueError('Deployment policy status must be active or disabled.')
    cluster = db.session.get(Cluster, cluster_id)
    if cluster is None:
        raise ValueError('Selected cluster does not exist.')
    registry = get_resolver_registry(current_app)
    registry.describe(action_key)
    current_fingerprint = str(current_app.config.get('RESOLVER_REGISTRY_FINGERPRINT') or '').strip()
    requested_fingerprint = str(required_registry_fingerprint or '').strip()
    if requested_fingerprint and requested_fingerprint != current_fingerprint:
        raise ValueError('Required registry fingerprint does not match the current KAORI resolver registry.')
    pinned_fingerprint = requested_fingerprint or current_fingerprint or None
    namespaces = sorted({item.strip() for item in allowed_namespaces if item.strip()})
    if lifecycle_status == 'active' and not namespaces:
        raise ValueError('An active resolver deployment policy requires an explicit namespace allowlist.')

    record = ResolverDeploymentPolicy.query.filter_by(cluster_id=cluster_id, action_key=action_key).one_or_none()
    created = record is None
    if record is None:
        record = ResolverDeploymentPolicy()
        record.cluster_id = cluster_id
        record.action_key = action_key
        record.created_by_user_id = actor_user_id
        db.session.add(record)
    record.lifecycle_status = lifecycle_status
    record.allowed_namespaces_json = namespaces
    record.required_registry_fingerprint = pinned_fingerprint
    record.updated_by_user_id = actor_user_id

    event = AuditEvent()
    event.actor_user_id = actor_user_id
    event.target_type = 'resolver_deployment_policy'
    event.target_id = f'{cluster_id}:{action_key}'
    event.action = 'resolver.deployment_policy.created' if created else 'resolver.deployment_policy.updated'
    event.summary = 'KAORI resolver deployment policy updated.'
    event.metadata_json = {
        'cluster_id': cluster_id,
        'action_key': action_key,
        'lifecycle_status': lifecycle_status,
        'allowed_namespaces': namespaces,
        'required_registry_fingerprint': record.required_registry_fingerprint,
    }
    db.session.add(event)
    db.session.commit()
    return record


def _workspace_rows(active: str) -> list[dict[str, str | bool]]:
    definitions = (
        ('overview', 'Foundation Map', 'layers-3', 'Domains 1–20 and their operator surfaces.'),
        (
            'runbooks',
            'Runbooks & Bindings',
            'book-open-check',
            'Author, validate, publish, and bind immutable runbooks.',
        ),
        ('decisions', 'Decision Review', 'clipboard-check', 'Review candidates, approvals, and execution journals.'),
        (
            'operations',
            'Resolver Operations',
            'server-cog',
            'Control deployment policy, safety posture, and dead letters.',
        ),
        ('readiness', 'Production Readiness', 'shield-check', 'Record evidence and advance staged rollout.'),
    )
    return [
        {'key': key, 'label': label, 'icon': icon, 'description': description, 'active': key == active}
        for key, label, icon, description in definitions
    ]


def _registry_rows() -> tuple[list[dict[str, Any]], str]:
    try:
        registry = get_resolver_registry(current_app)
    except Exception:
        return [], str(current_app.config.get('RESOLVER_REGISTRY_FINGERPRINT') or '')
    rows = []
    for action_key in registry.registered_actions():
        descriptor = registry.describe(action_key)
        rows.append(
            {
                'action_key': descriptor.action_key,
                'capabilities': list(descriptor.capability_keys),
                'profiles': list(descriptor.compatibility_profiles),
                'rollback_required': descriptor.rollback_required,
            }
        )
    return rows, str(current_app.config.get('RESOLVER_REGISTRY_FINGERPRINT') or '')


def _paginate_query(query: Any, *, page: Any, per_page: Any) -> tuple[list[Any], dict[str, Any]]:
    window = build_pagination_window(total_items=query.count(), page=page, per_page=per_page)
    rows = query.offset(window.offset).limit(window.per_page).all()
    return rows, {**window.as_dict(), 'allowed_per_page': PER_PAGE_OPTIONS}


def _paginate_sequence(rows: Sequence[Any], *, page: Any, per_page: Any) -> tuple[list[Any], dict[str, Any]]:
    window = build_pagination_window(total_items=len(rows), page=page, per_page=per_page)
    return list(rows[window.offset : window.offset + window.per_page]), {
        **window.as_dict(),
        'allowed_per_page': PER_PAGE_OPTIONS,
    }


def _domain_row(item: DomainDefinition) -> dict[str, Any]:
    return {
        'number': item.number,
        'title': item.title,
        'layer': item.layer,
        'operator_surface': item.operator_surface,
        'evidence': item.evidence,
        'status': 'Operational foundation',
        'tone': 'normal',
    }


def _runbook_row(record: KnowledgeRunbook) -> dict[str, Any]:
    revisions = list(record.revisions or [])
    published = [item for item in revisions if item.publication_status == 'published']
    return {
        'id': record.id,
        'key': record.runbook_key,
        'title': record.title,
        'description': record.description or 'No description recorded.',
        'status': record.lifecycle_status,
        'revision_count': len(revisions),
        'published_count': len(published),
        'updated_at': present_user_datetime(record.updated_at),
    }


def _revision_row(record: KnowledgeRunbookRevision) -> dict[str, Any]:
    validation = record.publication_validation_json or {}
    return {
        'id': record.id,
        'runbook_key': record.runbook.runbook_key,
        'version': record.version,
        'action_key': record.action_key,
        'resolver_key': record.resolver_key,
        'status': record.publication_status,
        'approval_policy': record.approval_policy,
        'validation_valid': validation.get('valid'),
        'validation_errors': list(validation.get('errors') or []),
        'created_at': present_user_datetime(record.created_at),
    }


def _binding_row(record: KnowledgeRunbookAlertBinding) -> dict[str, Any]:
    return {
        'id': record.id,
        'binding_key': record.binding_key,
        'runbook_key': record.revision.runbook.runbook_key,
        'version': record.revision.version,
        'selector': record.rule_key or record.alertname or '-',
        'cluster_id': record.cluster_id or 'All clusters',
        'namespace': record.namespace or 'All namespaces',
        'priority': record.priority,
        'status': record.lifecycle_status,
    }


def _candidate_row(record: IntelligenceDecisionCandidate, cluster_names: Mapping[str, str]) -> dict[str, Any]:
    candidate = record.candidate_json or {}
    return {
        'id': record.id,
        'public_id': record.public_id,
        'rule_key': record.rule_key or candidate.get('rule_key') or '-',
        'action_key': candidate.get('action_key') or '-',
        'runbook_key': candidate.get('runbook_key') or '-',
        'runbook_version': candidate.get('runbook_version') or '-',
        'cluster': cluster_names.get(str(record.cluster_id), record.cluster_id or 'Global'),
        'namespace': record.namespace or 'All namespaces',
        'severity': record.severity,
        'status': record.review_status,
        'expires_at': present_user_datetime(record.expires_at),
        'created_at': present_user_datetime(record.created_at),
    }


def _decision_row(record: IntelligenceDecision, cluster_names: Mapping[str, str]) -> dict[str, Any]:
    return {
        'id': record.id,
        'public_id': record.public_id,
        'rule_key': record.rule_key,
        'action_key': record.action_key,
        'runbook_key': record.runbook_key or '-',
        'cluster': cluster_names.get(str(record.cluster_id), record.cluster_id or 'Global'),
        'namespace': record.namespace or 'All namespaces',
        'severity': record.severity,
        'policy': record.policy_outcome,
        'approval_required': record.approval_required,
        'status': record.workflow_status,
        'expires_at': present_user_datetime(record.expires_at),
    }


def _journal_row(record: IntelligenceExecutionJournal, cluster_names: Mapping[str, str]) -> dict[str, Any]:
    decision = record.decision
    return {
        'id': record.id,
        'public_id': record.public_id,
        'action_key': record.action_key,
        'cluster': cluster_names.get(str(decision.cluster_id), decision.cluster_id or 'Global'),
        'namespace': decision.namespace or 'All namespaces',
        'status': record.status,
        'orchestration_status': record.orchestration_status,
        'attempts': f'{record.attempt_count}/{record.max_attempts}',
        'error': record.error_message or record.last_error_code or '-',
        'updated_at': present_user_datetime(record.updated_at),
    }


def _policy_row(record: ResolverDeploymentPolicy, cluster_names: Mapping[str, str]) -> dict[str, Any]:
    return {
        'id': record.id,
        'cluster_id': record.cluster_id,
        'cluster': cluster_names.get(str(record.cluster_id), record.cluster_id),
        'action_key': record.action_key,
        'status': record.lifecycle_status,
        'namespaces': list(record.allowed_namespaces_json or []),
        'fingerprint': record.required_registry_fingerprint or 'Current process registry',
        'updated_at': present_user_datetime(record.updated_at),
    }


def _control_row(record: ResolverOperationalControl, cluster_names: Mapping[str, str]) -> dict[str, Any]:
    return {
        'id': record.id,
        'cluster_id': record.cluster_id or '',
        'scope': cluster_names.get(str(record.cluster_id), record.cluster_id) if record.cluster_id else 'Global',
        'kill_switch': record.global_kill_switch,
        'maintenance_mode': record.maintenance_mode,
        'concurrency_limit': record.concurrency_limit,
        'rate_limit': record.rate_limit_per_minute,
        'failure_threshold': record.circuit_failure_threshold,
        'cooldown_seconds': record.circuit_cooldown_seconds,
        'circuit_open_until': present_user_datetime(record.circuit_open_until, empty='Closed'),
        'updated_at': present_user_datetime(record.updated_at),
    }


def _readiness_row(record: ResolverProductionReadinessRecord, cluster_names: Mapping[str, str]) -> dict[str, Any]:
    try:
        assessment = assess_readiness(results=record.validation_results_json, rollout_stage=record.rollout_stage)
        failed_checks = list(assessment.failed_checks)
        ready = assessment.ready
    except Exception as exc:
        failed_checks = [str(exc)]
        ready = False
    completed = sum(1 for key in REQUIRED_CHECKS if record.validation_results_json.get(key) is True)
    return {
        'id': record.id,
        'cluster_id': record.cluster_id,
        'cluster': cluster_names.get(str(record.cluster_id), record.cluster_id),
        'action_key': record.action_key,
        'stage': record.rollout_stage,
        'ready': ready,
        'completed_checks': completed,
        'total_checks': len(REQUIRED_CHECKS),
        'failed_checks': failed_checks,
        'evidence_hash': record.evidence_hash or '-',
        'validated_at': present_user_datetime(record.validated_at, empty='Not validated'),
        'approved_at': present_user_datetime(record.approved_at, empty='Not approved'),
    }


def _resolver_metrics() -> dict[str, int]:
    statuses = dict(
        db.session.query(
            IntelligenceExecutionJournal.orchestration_status,
            db.func.count(IntelligenceExecutionJournal.id),
        )
        .group_by(IntelligenceExecutionJournal.orchestration_status)
        .all()
    )
    return {
        'queued': int(statuses.get('queued', 0)),
        'running': int(statuses.get('running', 0)),
        'retry_wait': int(statuses.get('retry_wait', 0)),
        'dead_letter': int(statuses.get('dead_letter', 0)),
    }


def status_label(value: str | None) -> str:
    return present_key_label(value, empty='Unknown')
