from __future__ import annotations

from datetime import datetime
from typing import Any


def percent_display(value: Any, *, digits: int = 1) -> str:
    try:
        return f'{float(value or 0):.{digits}f}%'
    except (TypeError, ValueError):
        return '0.0%'


def gib_display(value_bytes: Any, *, digits: int = 2) -> str:
    try:
        return f'{float(value_bytes or 0) / (1024**3):.{digits}f} GiB'
    except (TypeError, ValueError):
        return '0.00 GiB'


def datetime_display(value: datetime | None, *, fallback: str = 'Not recorded') -> str:
    if value is None:
        return fallback
    return value.strftime('%d %b %Y, %H:%M %Z').strip()


def present_capacity_context(context: dict[str, Any]) -> dict[str, Any]:
    result = dict(context)
    raw_capacity_summary = result.get('capacity_summary')
    capacity_summary = raw_capacity_summary if isinstance(raw_capacity_summary, dict) else {}
    normalized_capacity_summary: dict[str, dict[str, Any]] = {}
    headroom_values: list[float] = []

    for resource in ('cpu', 'memory', 'pods', 'storage'):
        raw_item = capacity_summary.get(resource)
        item = dict(raw_item) if isinstance(raw_item, dict) else {}

        try:
            capacity = float(item.get('capacity') or 0)
        except (TypeError, ValueError):
            capacity = 0.0
        try:
            headroom = float(item.get('headroom') or 0)
        except (TypeError, ValueError):
            headroom = 0.0

        item['capacity'] = round(capacity, 2)
        for field in ('used', 'available'):
            try:
                item[field] = round(float(item.get(field) or 0), 2)
            except (TypeError, ValueError):
                item[field] = 0.0
        headroom = round(max(min(headroom, 100.0), 0.0), 1)
        item['headroom'] = headroom
        item['utilization_percent'] = (
            round(max(min(100.0 - headroom, 100.0), 0.0), 1)
            if capacity > 0
            else 0.0
        )
        normalized_capacity_summary[resource] = item

        result[f'{resource}_headroom'] = headroom
        result[f'{resource}_headroom_display'] = percent_display(headroom)
        if capacity > 0:
            headroom_values.append(headroom)

    result['capacity_summary'] = normalized_capacity_summary
    capacity_headroom_available = bool(headroom_values)
    lowest_headroom = min(headroom_values) if capacity_headroom_available else 0.0
    result['capacity_headroom_available'] = capacity_headroom_available
    result['lowest_headroom'] = lowest_headroom
    result['lowest_headroom_display'] = percent_display(lowest_headroom) if capacity_headroom_available else 'N/A'

    risk_summary = result.get('risk_summary')
    if isinstance(risk_summary, list):
        for item in risk_summary:
            if isinstance(item, dict) and 'headroom' in item:
                item['headroom_display'] = percent_display(item.get('headroom'))
                item['headroom_integer_display'] = percent_display(item.get('headroom'), digits=0)

    for key in ('headroom_nodes', 'capacity_nodes', 'worker_nodes'):
        values = result.get(key)
        if isinstance(values, list):
            for item in values:
                if isinstance(item, dict) and 'headroom' in item:
                    item['headroom_display'] = percent_display(item.get('headroom'))
                    item['headroom_integer_display'] = percent_display(item.get('headroom'), digits=0)
    return result


def present_utilization_context(context: dict[str, Any]) -> dict[str, Any]:
    result = dict(context)
    cluster_info = result.get('cluster_info')
    if cluster_info is not None:
        setattr(cluster_info, 'memory_capacity_display', gib_display(getattr(cluster_info, 'memory_capacity', 0)))
    summary = result.get('summary')
    if summary is not None:
        usage = gib_display(getattr(summary, 'memory_usage', 0))
        capacity = gib_display(getattr(summary, 'memory_capacity', 0))
        setattr(summary, 'memory_detail_display', f'{usage} / {capacity}')
    result['ready_ratio_display'] = percent_display(result.get('ready_ratio'), digits=0)
    detail = result.get('detail_summary')
    if detail is not None:
        usage = gib_display(getattr(detail, 'memory_usage', 0))
        capacity = gib_display(getattr(detail, 'memory_capacity', 0))
        setattr(detail, 'memory_detail_display', f'{usage} / {capacity}')
    return result
