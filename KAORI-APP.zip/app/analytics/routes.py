from hashlib import sha256

from flask import Blueprint, redirect, render_template, request, session, url_for
from flask_login import current_user

from app.analytics.alerts.routes import (
    alerts,
    alerts_table,
    anomalies_table,
)
from app.analytics.capacity.routes import capacity
from app.analytics.common.context import build_analysis_utilization_context
from app.analytics.forecast.routes import (
    forecast,
    forecast_section,
)
from app.analytics.overview.service import get_analytics_overview, get_analytics_overview_section
from app.analytics.storage.routes import (
    storage,
    storage_filesystem_summary,
    storage_persistent_summary,
)
from app.analytics.top_consumers.routes import (
    top_consumers,
    top_consumers_section,
    top_consumers_table,
)
from app.analytics.utilization.routes import (
    utilization,
    utilization_node_detail,
    utilization_trend,
)
from app.analytics.workload.routes import (
    workload,
    workload_resource_mapping,
    workload_tenant_quota,
)
from app.common.dependencies import render_dependency_blocker
from app.common.integration_errors import describe_integration_failure
from app.notifications.service import (
    get_navigation_notification_context,
    record_operational_activity,
)
from app.rbac.decorators import permission_required

analytics_bp = Blueprint(
    'analytics',
    __name__,
    url_prefix='/analytics',
)


VALID_ANALYTICS_TIME_RANGES = {
    '1h',
    '6h',
    '12h',
    '24h',
    '7d',
    '30d',
    '60d',
}


PROMETHEUS_FAILURE_SESSION_KEY = 'analytics_overview_prometheus_failures'
PROMETHEUS_FAILURE_SESSION_LIMIT = 32


def _render_operational_toast(feedback: dict) -> str:
    return render_template(
        'components/navigation/_quick_sync_result.html',
        **feedback,
        toast_oob=True,
        notification_context=get_navigation_notification_context(
            user_id=current_user.id,
        ),
    )


def _update_prometheus_failure_state(
    *,
    cluster_id: str,
    fingerprint: str | None,
) -> bool:
    state = dict(
        session.get(
            PROMETHEUS_FAILURE_SESSION_KEY,
            {},
        )
    )

    if fingerprint is None:
        if cluster_id in state:
            state.pop(cluster_id, None)
            session[PROMETHEUS_FAILURE_SESSION_KEY] = state
            session.modified = True
        return False

    if state.get(cluster_id) == fingerprint:
        return False

    state[cluster_id] = fingerprint
    if len(state) > PROMETHEUS_FAILURE_SESSION_LIMIT:
        oldest_cluster_id = next(iter(state))
        state.pop(oldest_cluster_id, None)

    session[PROMETHEUS_FAILURE_SESSION_KEY] = state
    session.modified = True
    return True


def _build_prometheus_failure_feedback(payload: dict) -> str:
    prometheus = payload.get('prometheus') or {}
    selected_cluster = payload.get('selected_cluster') or {}
    cluster_id = str(selected_cluster.get('id') or payload.get('selected_cluster_id') or '')

    if not cluster_id:
        return ''

    if prometheus.get('connected') or not prometheus.get('configured'):
        _update_prometheus_failure_state(
            cluster_id=cluster_id,
            fingerprint=None,
        )
        return ''

    endpoint = str(prometheus.get('endpoint') or '').strip()
    diagnostic_detail = str(
        prometheus.get('diagnostic_detail')
        or 'The Prometheus health check did not complete successfully.'
    ).strip()
    fingerprint = sha256(
        f'{endpoint}|{diagnostic_detail}'.encode('utf-8'),
    ).hexdigest()

    if not _update_prometheus_failure_state(
        cluster_id=cluster_id,
        fingerprint=fingerprint,
    ):
        return ''

    failure = describe_integration_failure(
        RuntimeError(diagnostic_detail),
        service_name='Prometheus',
        endpoint=endpoint,
        request_path='/api/v1/query',
    )
    cluster_name = str(selected_cluster.get('name') or 'Selected cluster')
    environment = str(selected_cluster.get('environment') or '')

    feedback = record_operational_activity(
        user_id=current_user.id,
        event_type='prometheus_health_check_failed',
        status='error',
        title='Prometheus connection failed',
        message=f'Prometheus is unreachable for {cluster_name}.',
        detail=str(failure['detail']),
        metadata={
            'cluster_id': cluster_id,
            'cluster_name': cluster_name,
            'environment': environment,
            'endpoint': endpoint,
            'failure_code': failure['code'],
            'reason': failure['reason'],
            'endpoint_host': failure['endpoint_host'],
            'endpoint_port': failure['endpoint_port'],
            'request_path': failure['request_path'],
        },
    )

    return _render_operational_toast(feedback)


@analytics_bp.route(
    '/',
    methods=[
        'GET',
    ],
)
@permission_required('analytics.view')
def overview():
    selected_cluster_id = request.args.get('cluster_id')
    selected_time_range = request.args.get(
        'time_range',
        '24h',
    )

    if selected_time_range not in VALID_ANALYTICS_TIME_RANGES:
        selected_time_range = '24h'

    payload = get_analytics_overview(
        selected_cluster_id=selected_cluster_id,
        time_range=selected_time_range,
        hydrate_live_sections=False,
    )
    _, _, _, dependency_context = build_analysis_utilization_context(
        request.args,
        check_prometheus_connection=False,
    )

    return render_template(
        'analytics/overview/index.html',
        payload=payload,
        dependency_blocker=dependency_context['dependency_blocker'],
    )


@analytics_bp.route(
    '/overview/section/<string:section>',
    methods=[
        'GET',
    ],
)
@permission_required('analytics.view')
def overview_section(section: str):
    allowed_sections = {
        'health-summary': 'analytics/overview/partials/_health_summary.html',
        'hero-posture': 'analytics/overview/partials/_hero_posture.html',
        'prometheus-status': 'analytics/overview/partials/_prometheus_status.html',
        'resource-snapshot': 'analytics/overview/partials/_resource_snapshot.html',
        'capacity-snapshot': 'analytics/overview/partials/_capacity_snapshot.html',
        'actionable-recommendations': 'analytics/overview/partials/_actionable_recommendation_summary.html',
        'storage-snapshot': 'analytics/overview/partials/_storage_snapshot.html',
        'workload-snapshot': 'analytics/overview/partials/_workload_snapshot.html',
        'top-consumers': 'analytics/overview/partials/_top_consumers_snapshot.html',
        'forecast-snapshot': 'analytics/overview/partials/_forecast_snapshot.html',
        'alerts-snapshot': 'analytics/overview/partials/_alerts_snapshot.html',
        'recommendations': 'analytics/overview/partials/_recommendations.html',
    }

    template_name = allowed_sections.get(section)

    if not template_name:
        return '', 404

    selected_time_range = request.args.get(
        'time_range',
        '24h',
    )

    if selected_time_range not in VALID_ANALYTICS_TIME_RANGES:
        selected_time_range = '24h'

    if request.headers.get('HX-Request') != 'true':
        return redirect(
            url_for(
                'analytics.overview',
                cluster_id=request.args.get('cluster_id'),
                time_range=selected_time_range,
            )
        )

    _, _, _, dependency_context = build_analysis_utilization_context(
        request.args,
        check_prometheus_connection=False,
    )
    dependency_blocker = dependency_context['dependency_blocker']

    if dependency_blocker:
        return render_dependency_blocker(
            dependency_blocker,
        )

    payload = get_analytics_overview_section(
        section=section,
        selected_cluster_id=request.args.get('cluster_id'),
        time_range=selected_time_range,
    )

    section_html = render_template(
        template_name,
        payload=payload,
    )

    if section == 'prometheus-status':
        return f'{section_html}{_build_prometheus_failure_feedback(payload)}'

    return section_html


analytics_bp.add_url_rule(
    '/utilization',
    endpoint='utilization',
    view_func=utilization,
)

analytics_bp.add_url_rule(
    '/utilization/node-detail',
    endpoint='utilization_node_detail',
    view_func=utilization_node_detail,
)

analytics_bp.add_url_rule(
    '/utilization/trend',
    endpoint='utilization_trend',
    view_func=utilization_trend,
)

analytics_bp.add_url_rule(
    '/capacity',
    endpoint='capacity',
    view_func=capacity,
    methods=[
        'GET',
    ],
)

analytics_bp.add_url_rule(
    '/storage',
    endpoint='storage',
    view_func=storage,
    methods=[
        'GET',
    ],
)

analytics_bp.add_url_rule(
    '/storage/filesystem-summary',
    endpoint='storage_filesystem_summary',
    view_func=storage_filesystem_summary,
    methods=[
        'GET',
    ],
)

analytics_bp.add_url_rule(
    '/storage/persistent-summary',
    endpoint='storage_persistent_summary',
    view_func=storage_persistent_summary,
    methods=[
        'GET',
    ],
)

analytics_bp.add_url_rule(
    '/workload',
    endpoint='workload',
    view_func=workload,
    methods=[
        'GET',
    ],
)

analytics_bp.add_url_rule(
    '/workload/tenant-quota',
    endpoint='workload_tenant_quota',
    view_func=workload_tenant_quota,
    methods=[
        'GET',
    ],
)

analytics_bp.add_url_rule(
    '/workload/resource-mapping',
    endpoint='workload_resource_mapping',
    view_func=workload_resource_mapping,
    methods=[
        'GET',
    ],
)

analytics_bp.add_url_rule(
    '/forecast',
    endpoint='forecast',
    view_func=forecast,
    methods=[
        'GET',
    ],
)

analytics_bp.add_url_rule(
    '/forecast/section',
    endpoint='forecast_section',
    view_func=forecast_section,
    methods=[
        'GET',
    ],
)

analytics_bp.add_url_rule(
    '/top-consumers',
    endpoint='top_consumers',
    view_func=top_consumers,
    methods=[
        'GET',
    ],
)

analytics_bp.add_url_rule(
    '/top-consumers/section',
    endpoint='top_consumers_section',
    view_func=top_consumers_section,
    methods=[
        'GET',
    ],
)

analytics_bp.add_url_rule(
    '/top-consumers/table',
    endpoint='top_consumers_table',
    view_func=top_consumers_table,
    methods=[
        'GET',
    ],
)

analytics_bp.add_url_rule(
    '/alerts',
    endpoint='alerts',
    view_func=alerts,
    methods=[
        'GET',
    ],
)

analytics_bp.add_url_rule(
    '/alerts-anomalies',
    endpoint='alerts_anomalies',
    view_func=alerts,
    methods=[
        'GET',
    ],
)

analytics_bp.add_url_rule(
    '/alerts/table',
    endpoint='alerts_table',
    view_func=alerts_table,
    methods=[
        'GET',
    ],
)

analytics_bp.add_url_rule(
    '/alerts/anomalies',
    endpoint='alerts_anomalies_table',
    view_func=anomalies_table,
    methods=[
        'GET',
    ],
)


@analytics_bp.route('/anomalies')
@permission_required('analytics.view')
def anomalies():
    return redirect(
        url_for(
            'analytics.alerts',
        )
    )
