"""ConfigMap Management operational domain."""
