"""Kubernetes inventory topology domain."""
