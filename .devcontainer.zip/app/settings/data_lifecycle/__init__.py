"""Data lifecycle settings workspace."""
