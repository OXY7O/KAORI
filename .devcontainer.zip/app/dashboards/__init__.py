"""KAORI package boundary."""
