"""Operational notification domain."""
