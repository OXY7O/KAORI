class OverviewQueries:
    pass
