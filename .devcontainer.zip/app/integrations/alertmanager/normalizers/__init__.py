"""Alertmanager payload normalizers."""
