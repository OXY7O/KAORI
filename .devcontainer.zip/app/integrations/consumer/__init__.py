"""Provider consumer result contracts."""
