"""Authentication provider implementations."""
