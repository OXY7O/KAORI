class OverviewQueries:
    pass
